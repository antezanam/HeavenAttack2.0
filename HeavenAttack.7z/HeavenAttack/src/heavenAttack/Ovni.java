package heavenAttack;

import java.io.File;
import java.net.MalformedURLException;
import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class Ovni extends Circle {

	private Random r;
	private double radio;

	public Ovni() {
		r = new Random();

		this.setCenterX(-100);
		this.setCenterY(-100);
		this.setRadius(radio);
	}

	public void mover(double velocidad) throws MalformedURLException {
		double y =  this.getCenterY();
		y += 1+velocidad*0.1;
		this.setCenterY(y); 
	}

	public void init(double ancho, double alto, double radio) throws MalformedURLException {
		File file = new File("img/ovni.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);

		this.setFill(new ImagePattern(img));
		this.setCenterX(ancho);
		this.setCenterY(alto);
		this.setRadius(radio);
	}
}