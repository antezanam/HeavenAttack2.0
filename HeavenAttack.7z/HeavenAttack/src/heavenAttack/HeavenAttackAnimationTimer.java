package heavenAttack;

import java.net.MalformedURLException;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class HeavenAttackAnimationTimer extends AnimationTimer {

	@FXML
	private Pane paneCancha;
	@FXML
	private Pane paneDerrota;
	@FXML
	private Label labelPuntaje;
	private Jugador jugador;
	private Costados costados;
	private Costados2 costados2;
	private Proyectiles proyectiles;
	private Ovnis ovnis;
	private int puntaje;
	private boolean inicio;

	public HeavenAttackAnimationTimer(Pane paneCancha, Costados costados, Costados2 costados2,Proyectiles proyectiles, Ovnis ovnis, Label labelPuntaje, boolean inicio, Jugador jugador, Pane paneDerrota ) {
		this.paneCancha = paneCancha;
		this.costados = costados;
		this.costados2 = costados2;
		this.proyectiles = proyectiles;
		this.ovnis= ovnis;
		this.puntaje = 0;
		this.labelPuntaje = labelPuntaje;
		this.inicio = inicio;
		this.jugador = jugador;
		this.paneDerrota = paneDerrota;
		this.paneDerrota.setVisible(false);
	}

	@Override
	public void handle(long arg0) {
		if(inicio == true) {
			proyectiles.mover();
			
			if (costados.getEstado())
				try {
					costados.mover();
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}
			
			if (costados2.getEstado())
				try {
					costados2.mover();
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}	
			
			if(ovnis.getEstado()){
				try {
					ovnis.mover();
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}
			}

			for(int i=0; i<ovnis.getTamano(); i++) {
				if(proyectiles.getProyectil().intersects(ovnis.getOvni(i).getBoundsInLocal())){
					puntaje += 100;
					proyectiles.getProyectil().setCenterX(-100);
					proyectiles.getProyectil().setCenterY(-100);
					ovnis.getOvni(i).setCenterX(-500);
					ovnis.getOvni(i).setCenterY(-500);
					labelPuntaje.setText(""+puntaje);
				}
			}
			
			for(int i=0; i<ovnis.getTamano(); i++) {
				if(jugador.intersects(ovnis.getOvni(i).getBoundsInLocal())) {
					jugador.setCenterX(-200);
					jugador.setCenterY(-200);
					paneDerrota.setVisible(true);
					for(int n=0; n<ovnis.getTamano(); n++) {
						ovnis.getOvni(n).setCenterX(-500);
						ovnis.getOvni(n).setCenterY(-500);
					}
				}
			}

			for(int i=0; i<costados.getTamano(); i++) {
				if(jugador.intersects(costados.getCostado(i).getBoundsInLocal())) {
					jugador.setCenterX(-200);
					jugador.setCenterY(-200);
					paneDerrota.setVisible(true);
					for(int n=0; n<ovnis.getTamano(); n++) {
						ovnis.getOvni(n).setCenterX(-500);
						ovnis.getOvni(n).setCenterY(-500);
					}
				}
			}

			for(int i=0; i<costados2.getTamano(); i++) {
				if(jugador.intersects(costados2.getCostado2(i).getBoundsInLocal())) {
					jugador.setCenterX(-200);
					jugador.setCenterY(-200);
					ovnis.getOvni(i).setCenterX(-500);
					ovnis.getOvni(i).setCenterY(-500);
					paneDerrota.setVisible(true);
					for(int n=0; n<ovnis.getTamano(); n++) {
						ovnis.getOvni(n).setCenterX(-500);
						ovnis.getOvni(n).setCenterY(-500);
					}
				}
			}
		}
	}
}