package heavenAttack;

import javafx.scene.layout.Pane;

public class Proyectiles {
	
	private Proyectil proyectiles[];
	private boolean visible;
	private int contador;
	private int municion;

	public Proyectiles(int n, Jugador jugador) {
		proyectiles = new Proyectil[n];
		for (int i=0; i<n; i++)
			proyectiles[i] = new Proyectil(jugador);
		visible = false;
		contador = 0;
		municion = n;
	}

	public Proyectil getProyectil() {
		if (contador > 0) {
			return proyectiles[contador-1];
		}
		else
		{
			return proyectiles[0];
		}
	}

	public void cambiaEstado() {
		visible = true;
	}

	public boolean getEstado() {
		return visible;
	}

	public void add (Pane paneCancha) {
		for(int n = 0; n<proyectiles.length;n++){
			paneCancha.getChildren().add(proyectiles[n]);
		}
	}

	public void mover() {
		for (int i=0; i<proyectiles.length; i++){
			proyectiles[i].mover();
		}
	}

	public void init() {
		if(contador<municion) {
			proyectiles[contador].init();
			contador ++;
		}
	}
}