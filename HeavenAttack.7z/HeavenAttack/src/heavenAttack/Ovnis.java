package heavenAttack;

import java.net.MalformedURLException;
import java.util.Random;

import javafx.scene.layout.Pane;

public class Ovnis {

	private Ovni ovnis[];
	private boolean visible;
	private double velocidad = 0;
	private Random r;
	private int tamano;

	public Ovnis(int n) {
		System.out.println("Constructor Ovnis");
		r = new Random();
		ovnis = new Ovni[n];

		for (int i=0; i<n; i++)
			ovnis[i] = new Ovni();
		visible = false;
		tamano = n;
	}

	public int getTamano() {
		return tamano;
	}
	
	public Ovni getOvni(int n) {
		return ovnis[n];
	}

	public void add(Pane paneCancha) {
		for (int i=0; i<ovnis.length; i++)
			paneCancha.getChildren().add(ovnis[i]);
	}

	public void cambiaEstado() {
		visible = true;
	}

	public boolean getEstado() {
		return visible;
	}

	public void mover() throws MalformedURLException {
		velocidad += 0.02;
		for (int i=0; i<ovnis.length; i++) {
			if(ovnis[i].getCenterY() >= 700) {
				ovnis[i].setCenterX(-200);
				ovnis[i].setCenterY(-200);
			}
			else {
				ovnis[i].mover(velocidad);
			}
		}
	}

	public void init(double radio) throws MalformedURLException {
		for (int i=0; i<ovnis.length; i++) {
			ovnis[i].init(r.nextInt(400)+100, 0*(r.nextInt(500)*-1)+(i*100)*-1, radio);
		}
	}
}