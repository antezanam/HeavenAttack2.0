package heavenAttack;

import java.net.MalformedURLException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;


public class HeavenAttackController {
	@FXML
	private AnchorPane anchorPane;
	@FXML
	private Pane paneCancha;
	@FXML 
	private Pane paneDerrota;
	@FXML
	private Label labelPuntaje;
	@FXML
	private Button botonSalir;
	@FXML
	private Button botonComenzar;
	private Jugador jugador;
	private Costados costados;
	private Costados2 costados2;
	private Proyectiles proyectiles;
	private Ovnis ovnis;
	private boolean inicio;
	private HeavenAttackAnimationTimer miTimer;

	@FXML
	public void initialize() throws MalformedURLException {
		Rectangle clip = new Rectangle(0, 0, 0, 0);
		clip.widthProperty().bind(paneCancha.widthProperty());
		clip.heightProperty().bind(paneCancha.heightProperty());
		paneCancha.setClip(clip);	

		jugador = new Jugador();
		paneCancha.getChildren().add(jugador);

		costados = new Costados(3);
		costados.add(paneCancha);

		costados2 = new Costados2(3);
		costados2.add(paneCancha);

		proyectiles = new Proyectiles(100, jugador);
		proyectiles.add(paneCancha);

		ovnis = new Ovnis(500);
		ovnis.add(paneCancha);

		inicio = true;

		miTimer = new HeavenAttackAnimationTimer( paneCancha,  costados, costados2, proyectiles, ovnis,  labelPuntaje,  inicio, jugador, paneDerrota );
	}

	@FXML
	public void botonComenzar() throws MalformedURLException {
		System.out.println("Comenzando...");
		miTimer.start();
		if(jugador.getCenterY()!=-620) {
			botonComenzar.setText("---");
		}
		if (!costados.getEstado()) {
			costados.cambiaEstado();
			costados.init();
		}
		if (!costados2.getEstado()) {
			costados2.cambiaEstado();
			costados2.init();
		}
		if (!ovnis.getEstado()) {
			ovnis.cambiaEstado();
			ovnis.init(40);
		}
	}

	@FXML
	public void botonSalir(){
		System.out.println("Saliendo...");
		System.exit(0);
	}

	@FXML
	public void keyMoveHnd(KeyEvent ke) {
		double x = jugador.getCenterX();
		double y = jugador.getCenterY();

		switch (ke.getCode()) {
		case LEFT:
			if (jugador.getCenterX() >= 25){
				x-=8;
			}
			else {
				x = 25;	
			}
			break;
		case RIGHT:
			if (jugador.getCenterX() <= 580){
				x+=8;
			}
			else {
				x = 580;	
			}
			break;
		case UP:
			proyectiles.init();
			;
			break;
		default:
			System.out.println("KeyMoveHnd:" + ke.getCode());
			break;
		}
		ke.consume();
		jugador.setCenterX(x);
		jugador.setCenterY(y);
	}
}