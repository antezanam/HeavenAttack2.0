package heavenAttack;

import java.io.File;
import java.net.MalformedURLException;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Costado2 extends Rectangle {

	private double width;
	private double height;

	public Costado2() {
		this.setX(-100);
		this.setY(-100);
		this.setHeight(height);
		this.setWidth(width);
	}

	public void mover(double velocidad) {
		double y = this.getY();
		y += 1+velocidad*0.1;
		this.setY(y);
	}

	public void init(double alto) throws MalformedURLException {
		File file = new File("img/montana.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);
		this.setFill(new ImagePattern(img));
		this.setX(500);
		this.setY(alto);
		this.setHeight(800);
		this.setWidth(100);
	}
}
