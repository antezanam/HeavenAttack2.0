package heavenAttack;

import java.io.File;
import java.net.MalformedURLException;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class Jugador extends Circle{
	
	public Jugador() throws MalformedURLException {
		this.init();
	}

	public void init() throws MalformedURLException {
		File file = new File("img/avion.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);
		this.setFill(new ImagePattern(img));
		this.setCenterX(300);
		this.setCenterY(620);
		this.setRadius(30);
	}
}