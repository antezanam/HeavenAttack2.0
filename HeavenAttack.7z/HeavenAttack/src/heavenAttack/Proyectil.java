package heavenAttack;

import javafx.scene.shape.Circle;

public class Proyectil extends Circle{

	private Jugador jugador;
	private double x;
	private double y;
	private boolean estado;

	public Proyectil(Jugador jugador) {
		x =- 100;
		y =- 100;
		estado = false;
		this.setCenterX(x);
		this.setCenterY(y);
		this.setRadius(5);
		this.jugador = jugador;
	}

	public void mover() {
		if(estado==true) {
			y -= 10;
			this.setCenterY(y);
			this.verificar(y);
		}
	}

	private void verificar(double y2) {
		if(y2 < -this.getRadius()){
			this.setCenterX(-100);
			this.setCenterY(-100);
			estado = false;
		}
	}

	public void init() {
		y = jugador.getCenterY();
		x = jugador.getCenterX();
		this.setCenterX(x);
		this.setCenterY(y);
		estado = true;
	}
}