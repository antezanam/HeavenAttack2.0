package heavenAttack;

import java.net.MalformedURLException;

import javafx.scene.layout.Pane;

public class Costados {

	private Costado costados[];
	private boolean visible;
	private double velocidad=0;
	private int tamano;

	public Costados(int n) {
		costados = new Costado[n];
		for (int i=0; i<n; i++)
			costados[i] = new Costado();
		visible = false;
		tamano = n;
	}

	public int getTamano() {
		return tamano;
	}

	public Costado getCostado(int n) {
		return costados[n];
	}

	public double getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(double velocidad) {
		this.velocidad = velocidad;
	}

	public void cambiaEstado() {
		visible = true;
	}

	public boolean getEstado() {
		return visible;
	}

	public void add(Pane paneCancha) {
		for (int i=0; i<costados.length; i++) {
			paneCancha.getChildren().add(costados[i]);
		}
	}

	public void mover() throws MalformedURLException {
		velocidad+= 0.01;
		for (int i=0; i<costados.length; i++){
			if (costados[2].getY()>=(0)) {
				this.init();
			}
			else {
				costados[i].mover( velocidad );
			}
		}
	}

	public void init() throws MalformedURLException {
		for (int i=0; i<costados.length; i++) {
			if (i==0){
				costados[0].init(0);
			}
			else if(i==1){
				costados[1].init(-(costados[i-1].getHeight()));
			}
			else {
				costados[2].init(-2*(costados[i-2].getHeight()));
			}
		}
	}
}