package heavenAttack;

import javafx.scene.shape.Circle;

public class Avion extends Circle {

	public Avion() {

		super();
		this.setCenterX(495);
		this.setCenterY(475);
		this.setRadius(15);
	}

}